package com.techlabs.app.exception;

public class BlogException extends RuntimeException{

	public BlogException(String message) {
		super(message);
	}
	
	

}
