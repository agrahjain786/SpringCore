package com.techlabs.app.service;

public interface EmailService {

	void sendSimpleMail(String email, String subject, String text);

}
