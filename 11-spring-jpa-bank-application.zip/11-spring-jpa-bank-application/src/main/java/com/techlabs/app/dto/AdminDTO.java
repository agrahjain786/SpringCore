package com.techlabs.app.dto;

public class AdminDTO {
	
	private int id;

}
